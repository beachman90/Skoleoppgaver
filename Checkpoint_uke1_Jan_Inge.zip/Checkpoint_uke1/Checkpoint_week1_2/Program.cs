﻿namespace Checkpoint_week1_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What would you like to do?");
            Console.WriteLine("\nSelect a number:\n");
            Console.WriteLine("1. Exit program");
            Console.WriteLine("2. Add consultant to list");
            Console.WriteLine("3. Write list to console.");
            Console.WriteLine("4. Empty the list");
            Console.WriteLine("5. Save list to file.");
            Console.WriteLine("6. Load list from file and print to screen\n");

            var input = int.Parse(Console.ReadLine());

            switch (input)
            {
                case 1:
                    Console.WriteLine("Exiting program.");
                    break;

                case 2:
                    AddToList();
                    break;

                case 3:
                    AddToList.WriteListToConsole();
                    break;

                case 4:
                    Console.WriteLine(4);
                    break;

                case 5:
                    Console.WriteLine(5);
                    break;

                case 6:
                    Console.WriteLine(6);
                    break;

                default:
                    Console.WriteLine("Choose a valid option using a number.");
                    break;




            }
        }
    }

    public class AddToList
    {
        List<Consultant> consultantList = new();
        public AddToList()
        {

            Console.WriteLine("Input name og consultant:");
            string name = Console.ReadLine();

            Console.WriteLine("Input consultant phonenumber:");
            string phoneNumber = Console.ReadLine();

            Consultant consultant1 = new(name, phoneNumber);
            consultantList.Add(consultant1);

        }

        public void WriteListToConsole()
        {
            foreach (Consultant consultant in consultantList)
            {
                Console.WriteLine(consultant);
            }
        }
    }
}